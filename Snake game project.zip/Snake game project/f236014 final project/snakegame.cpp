#include <iostream>
#include <cstdlib>
#include <ctime>
#include <conio.h>
#include <string>
#include <windows.h>
using namespace std;

bool game_over;
int board_width = 20;
int board_height = 20;
int snake_x, snake_y;
int fruit_x, fruit_y;
int score, lives, best_score;
int tail_x[100], tail_y[100];
int tail_length;
int dir; // 0 = stop, 1 = left, 2 = right, 3 = up, 4 = down

// Moves cursor to top-left for fast refresh
void setCursorPosition(int x, int y) {
    COORD pos;
    pos.X = x;
    pos.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}

void start_game() {
    srand(time(0));
    game_over = false;
    dir = 0;
    snake_x = board_width / 2;
    snake_y = board_height / 2;
    fruit_x = rand() % (board_width - 2) + 1;
    fruit_y = rand() % (board_height - 2) + 1;
    score = 0;
    tail_length = 0;
    lives = 3;
    best_score = 0;
}

void draw_board() {
    setCursorPosition(0, 0); // Faster than system("cls")

    // Top border
    cout << " * ";
    for (int i = 8; i < board_width; i++) cout << " * ";
    cout << " * " << endl;

    // Playing area
    for (int i = 0; i < board_height; i++) {
        cout << "*"; // left border
        for (int j = 0; j < board_width; j++) {
            if (i == snake_y && j == snake_x)
                cout << "~~"; // Snake head 
            else if (i == fruit_y && j == fruit_x)
                cout << "o ";
            else {
                bool print_tail = false;
                for (int k = 0; k < tail_length; k++) {
                    if (tail_x[k] == j && tail_y[k] == i) {
                        cout << "~~";
                        print_tail = true;
                        break;
                    }
                }
                if (!print_tail) cout << "  ";
            }
        }
        cout << "*" << endl; // right border
    }

    // Bottom border
    cout << " * ";
    for (int i = 8; i < board_width; i++) cout << " * ";
    cout << " * " << endl;

    cout << "Score: " << score << "  Lives: " << lives << "  Best: " << best_score << endl;
}


void get_input() {
    if (_kbhit()) {
        char key = _getch();
        if (key == 'a' || key == 'A') dir = 1;
        else if (key == 'd' || key == 'D') dir = 2;
        else if (key == 'w' || key == 'W') dir = 3;
        else if (key == 's' || key == 'S') dir = 4;
        else if (key == 'x' || key == 'X') {
            lives--;
            if (lives < 0) game_over = true;
        }
    }
}

void game_logic() {
    int prev_x = tail_x[0];
    int prev_y = tail_y[0];
    int temp_x, temp_y;
    tail_x[0] = snake_x;
    tail_y[0] = snake_y;

    for (int i = 1; i < tail_length; i++) {
        temp_x = tail_x[i];
        temp_y = tail_y[i];
        tail_x[i] = prev_x;
        tail_y[i] = prev_y;
        prev_x = temp_x;
        prev_y = temp_y;
    }

    if (dir == 1) snake_x--;
    else if (dir == 2) snake_x++;
    else if (dir == 3) snake_y--;
    else if (dir == 4) snake_y++;

    if (snake_x < 0 || snake_x >= board_width || snake_y < 0 || snake_y >= board_height) {
        lives--;
        if (lives < 0) game_over = true;
        else {
            snake_x = board_width / 2;
            snake_y = board_height / 2;
        }
    }

    for (int i = 0; i < tail_length; i++) {
        if (tail_x[i] == snake_x && tail_y[i] == snake_y) {
            lives--;
            if (lives < 0) game_over = true;
            else {
                snake_x = board_width / 2;
                snake_y = board_height / 2;
            }
        }
    }

    if (snake_x == fruit_x && snake_y == fruit_y) {
        score += 10;
        if (score > best_score) best_score = score;
        fruit_x = rand() % (board_width - 2) + 1;
        fruit_y = rand() % (board_height - 2) + 1;
        tail_length++;
    }
}

int main() {
    string player_name;
    char choice;

    do {
        cout << "Enter your name: ";
        getline(cin, player_name);

        start_game();

        while (!game_over) {
            draw_board();
            get_input();
            game_logic();
            Sleep(200); // slower refresh 
        }


        cout << "Game Over! " << player_name << ", your score: " << score << endl;
        cout << "Play again? (y/n): ";
        cin >> choice;
        cin.ignore();

    } while (choice == 'y' || choice == 'Y');

    cout << "Thanks for playing! Best score: " << best_score << endl;
    return 0;
}
